def generate_contact_requests_channel(user_id: str) -> str:
    return f"contact-requests:{user_id}"
