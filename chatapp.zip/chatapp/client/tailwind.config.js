module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    fontFamily: {
      // sans: ['-apple-system', 'Helvetica', 'Arial', 'sans-serif'],
      sans: ['Inter var', 'sans-serif'],
    },
    extend: {},
  },
  plugins: [],
};
