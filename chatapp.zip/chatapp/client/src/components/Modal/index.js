import { Modal } from "components/Modal/Modal";

export { Modal };
