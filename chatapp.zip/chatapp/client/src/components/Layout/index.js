import { MainLayout } from "components/Layout/MainLayout";

export { MainLayout };
