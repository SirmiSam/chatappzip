import Disclosure from "components/Disclosure/Disclosure";

export { Disclosure };
