export const ContactByFirstLetter = () => {
  return (
    <div className="mb-3 p-1">
      <h2 className="text-gray-200">A</h2>
      <label className="inline-flex items-center cursor-pointer text-sm text-slate-300 m-2">
        <input
          type="checkbox"
          className="mx-2 rounded-[3px] bg-gray-500 text-gray-600 focus:ring-0"
        />
        Lorem Ipsum
      </label>

      <br />

      <label className="inline-flex items-center cursor-pointer text-sm text-slate-300 m-2">
        <input
          type="checkbox"
          className="mx-2 rounded-[3px] bg-gray-500 text-gray-600 focus:ring-0"
        />
        Lorem Ipsum
      </label>
    </div>
  );
};
