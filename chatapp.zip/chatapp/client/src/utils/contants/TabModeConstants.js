export const PROFILE_MODE = "PROFILE_MODE";
export const CHAT_MODE = "CHAT_MODE";
export const GROUP_MODE = "GROUP_MODE";
export const CONTACT_MODE = "CONTACT_MODE";
export const SETTING_MODE = "SETTING_MODE";
export const NOTIFICATION_MODE = "NOTIFICATION_MODE";
