import NotificationSound from './notification-sound.mp3';

export { NotificationSound };
