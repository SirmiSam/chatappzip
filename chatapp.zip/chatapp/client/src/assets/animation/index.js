import WelcomeAnimation from "assets/animation/welcome.json";

export { WelcomeAnimation };
